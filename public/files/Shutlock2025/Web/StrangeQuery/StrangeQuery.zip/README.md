# StrangeQuery

## Description
Le festival de Cannes a mis à disposition un super site pour partager des avis sur des films. Il a l'air très récent, il doit sûrement y avoir beaucoup de vulnérabilités...

format du flag: SHLK{[a-zA-Z0-9_-']+}

## Information Admins
Besoin de lancer une instance par utilisateur.
flag: SHLK{S3CoNd_0RDeR_4rEN7_AwE50me_?}

## To-do
