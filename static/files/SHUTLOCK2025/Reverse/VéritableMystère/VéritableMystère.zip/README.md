# VéritableMystère

## Description
Ce script python me demande un mot de passe... Je ne sais pas quoi en faire :/

Format du flag: SHLK{[a-zA-Z0-9_-']+}

## Information Admins
Fournir le fichier source/VeritableMystere.py.
flag: SHLK{cE5TUNVRa!My$7eRe3NPY7h0nEnPlUs!}

## Comment build le challenge
Utiliser le script suivant en changeant la variable flag, `./source/generateChallenge.sh`.
Le fichier du challenge est `./source/VeritableMystere.py`, il peut être changer au début du script vu ci-dessus.

